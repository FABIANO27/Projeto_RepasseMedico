#!/usr/bin/env python3
"""Pipeline completo: base SQLite -> PDFs de demonstrativo -> leitura dos PDFs -> dashboards (docs/)."""
import subprocess, sys, pathlib
R = pathlib.Path(__file__).resolve().parent
S = R / "src"

def run(*args):
    print("\n$ python", " ".join(str(a) for a in args))
    subprocess.run([sys.executable, *map(str, args)], check=True, cwd=R)

if __name__ == "__main__":
    run(S / "gerar_base.py")
    for comp in ("2026-07", "2026-08", "2026-09"):
        run(S / "gerar_pdf.py", comp)
    run(S / "ler_pdf.py")
    print("\nPronto. Abra docs/index.html (desktop) ou docs/mobile.html no navegador.")
