# Dicionário de dados

Base SQLite `data/repasse_medico_mvsoul.db` (nomes de tabelas/colunas inspirados no modelo de Repasse Médico do MV: `cd_` código, `ds_` descrição,
`nm_` nome, `vl_` valor, `pc_` percentual, `dt_` data, `sn_` sim/não, `tp_` tipo).

## Cadastros

| Tabela | Colunas | Descrição |
|---|---|---|
| `especialidade` | `cd_especialidade`, `ds_especialidade` | 10 especialidades médicas |
| `centro_custo` | `cd_centro_custo`, `ds_centro_custo` | 8 centros de custo de apropriação (101 Centro Cirúrgico … 108 Maternidade) |
| `convenio` | `cd_convenio`, `nm_convenio` | Unimed, Bradesco Saúde, SulAmérica, Amil, SUS, Particular |
| `prestador` | `cd_prestador`, `nm_prestador`, `nr_crm`, `cd_especialidade`, `tp_vinculo`, `sn_ativo` | 40 médicos; vínculo: Corpo Clínico, PJ, Plantonista |
| `regra_repasse` | `cd_regra`, `cd_convenio`, `pc_repasse`, `ds_regra` | % de repasse padrão por convênio |

## Movimento

| Tabela | Colunas | Descrição |
|---|---|---|
| `repasse` | `cd_repasse`, `cd_prestador`, `dt_competencia`, `dt_repasse`, `vl_bruto`, `vl_glosa`, `vl_imposto`, `vl_liquido`, `sn_fechado` | Cabeçalho: um registro por médico e competência |
| `it_repasse` | `cd_it_repasse`, `cd_repasse`, `cd_atendimento`, `cd_pro_fat`, `ds_procedimento`, `cd_convenio`, `tp_atendimento`, `dt_lancamento`, `vl_total_conta`, `cd_regra`, `pc_repasse`, `vl_repasse`, `vl_glosa`, **`cd_centro_custo`** | Itens lançados; cada um é apropriado a um centro de custo |

Relacionamentos: `it_repasse.cd_repasse → repasse`, `repasse.cd_prestador → prestador`, `prestador.cd_especialidade → especialidade`,
`it_repasse.cd_convenio → convenio`, `it_repasse.cd_centro_custo → centro_custo`.

## Arquivo de carga (JSON `itens[]` / CSV)

Um registro por lançamento, já com os dados do cabeçalho do médico (formato “achatado” lido do PDF).

| Campo | Tipo | Origem / significado |
|---|---|---|
| `rep` | inteiro | Nº do repasse (`repasse.cd_repasse`) |
| `cd_med` | inteiro | Código do prestador |
| `med` | texto | Nome do médico |
| `crm` | texto | CRM |
| `esp` | texto | Especialidade |
| `vinc` | texto | Vínculo |
| `comp` | texto `AAAA-MM` | Competência |
| `atend` | inteiro | Nº do atendimento |
| `pac` | texto | Paciente (fictício, gerado a partir do nº do atendimento) |
| `dt` | data `AAAA-MM-DD` | Data do lançamento |
| `cod` / `proc` | texto | Código e descrição do procedimento |
| `conv` | texto | Convênio |
| `tp` | texto | Tipo de atendimento (Ambulatorial, Internação, Urgência) |
| `vl_conta` | decimal | Valor da conta |
| `pc` | decimal | % de repasse aplicado |
| `vl_rep` | decimal | Valor do repasse (`vl_conta × pc / 100`) |
| `glosa` | decimal | Glosa sobre o repasse |
| `cc` / `cc_ds` | inteiro / texto | Centro de custo de apropriação (código e descrição) |

Chave de atualização na aba *Carga* (modo *atualizar*): `rep + atend + cod + dt`.
