#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Demonstrativo de Repasse Médico — relatório em PDF inspirado no modelo de Repasse Médico do MV (MV Soul, módulo Custos).
Recriação própria com dados fictícios; sem vínculo com a MV Informática.
Lê data/repasse_medico_mvsoul.db (gerado por gerar_base.py) e emite:
  1) Resumo da competência por Centro de Custo (apropriação) e por Especialidade
  2) Um demonstrativo por prestador (1 médico = 1 seção), com itens, apropriação por C. Custo e totais
Uso:  python src/gerar_pdf.py [AAAA-MM | todas]     (padrão: 2026-09). Saída: data/pdf/
"""
import os, sqlite3, sys, random
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, "data", "repasse_medico_mvsoul.db")
HOSPITAL = "HOSPITAL SÃO LUCAS (FICTÍCIO)"
AZUL, CINZA = colors.HexColor("#0b3b6f"), colors.HexColor("#e6e9ee")
NOMES = ["MARIA", "JOSÉ", "ANA", "JOÃO", "ANTONIO", "FRANCISCA", "CARLOS", "ADRIANA", "PAULO", "LUCIA", "MARCOS", "SANDRA",
         "LUIZ", "ROSA", "PEDRO", "VERA", "RAFAEL", "CLÁUDIA", "DANIEL", "ELIANE"]
SOBRE = ["SILVA", "SANTOS", "OLIVEIRA", "SOUZA", "LIMA", "PEREIRA", "COSTA", "RODRIGUES", "ALVES", "MARTINS", "ROCHA",
         "RIBEIRO", "CARVALHO", "GOMES", "MENDES", "BARROS", "FREITAS", "NASCIMENTO", "ARAÚJO", "MOURA"]

S = lambda **k: ParagraphStyle("x", fontName=k.pop("f", "Helvetica"), fontSize=k.pop("s", 6.6), leading=k.pop("l", 8), **k)
sp, spb, sh = S(), S(f="Helvetica-Bold"), S(f="Helvetica-Bold", textColor=colors.white)
stit = S(f="Helvetica-Bold", s=11, l=14, textColor=AZUL)


def brl(v):
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def dtbr(iso):
    return f"{iso[8:10]}/{iso[5:7]}/{iso[0:4]}"

def paciente(cd):
    r = random.Random(cd)
    return f"{r.choice(SOBRE)} {r.choice(SOBRE)}, {r.choice(NOMES)}"

def estilo_tabela(extra=()):
    return TableStyle([("BACKGROUND", (0, 0), (-1, 0), AZUL), ("GRID", (0, 0), (-1, -1), .25, colors.HexColor("#b8c0cc")),
                       ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f7fa")]),
                       ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 1.5),
                       ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5), *extra])

def cab_pagina(titulo_rel, comp):
    def f(c, d):
        w, h = landscape(A4)
        c.saveState()
        c.setFillColor(AZUL); c.rect(10 * mm, h - 17 * mm, w - 20 * mm, 8 * mm, fill=1, stroke=0)
        c.setFillColor(colors.white); c.setFont("Helvetica-Bold", 9)
        c.drawString(12 * mm, h - 14.3 * mm, f"MV SOUL  |  {HOSPITAL}")
        c.drawRightString(w - 12 * mm, h - 14.3 * mm, "Módulo: Custos / Repasse Médico")
        c.setFillColor(colors.black); c.setFont("Helvetica-Bold", 9.5)
        c.drawString(10 * mm, h - 22 * mm, titulo_rel)
        c.setFont("Helvetica", 7.5)
        c.drawRightString(w - 10 * mm, h - 22 * mm, f"Competência: {comp}")
        c.setFillColor(colors.grey); c.setFont("Helvetica", 7)
        c.drawString(10 * mm, 6 * mm, f"Emitido em {datetime.now():%d/%m/%Y %H:%M}  —  Usuário: CUSTOS  —  Base fictícia")
        c.drawRightString(w - 10 * mm, 6 * mm, f"Pág. {d.page}")
        c.restoreState()
    return f


def resumo(con, comp):
    q = lambda s: con.execute(s, (comp,)).fetchall()
    el = [Paragraph("RESUMO DA COMPETÊNCIA — APROPRIAÇÃO POR CENTRO DE CUSTO", stit), Spacer(1, 4)]
    cc = q("""SELECT c.cd_centro_custo, c.ds_centro_custo, COUNT(*), SUM(i.vl_repasse), SUM(i.vl_glosa)
              FROM it_repasse i JOIN repasse r USING(cd_repasse) JOIN centro_custo c USING(cd_centro_custo)
              WHERE substr(r.dt_competencia,1,7)=? GROUP BY 1,2 ORDER BY 1""")
    d = [[Paragraph(x, sh) for x in ["C. Custo", "Descrição", "Qtd. itens", "Repasse bruto", "Glosa", "Repasse apropriado"]]]
    for r in cc:
        d.append([str(r[0]), r[1], str(r[2]), brl(r[3]), brl(r[4]), brl(r[3] - r[4])])
    d.append(["", "TOTAL", str(sum(r[2] for r in cc)), brl(sum(r[3] for r in cc)), brl(sum(r[4] for r in cc)),
              brl(sum(r[3] - r[4] for r in cc))])
    t = Table(d, colWidths=[22 * mm, 70 * mm, 25 * mm, 38 * mm, 30 * mm, 42 * mm], repeatRows=1)
    t.setStyle(estilo_tabela([("ALIGN", (2, 0), (-1, -1), "RIGHT"), ("FONTSIZE", (0, 1), (-1, -1), 7.5),
                              ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("BACKGROUND", (0, -1), (-1, -1), CINZA)]))
    el += [t, Spacer(1, 14), Paragraph("RESUMO POR ESPECIALIDADE", stit), Spacer(1, 4)]
    es = q("""SELECT e.ds_especialidade, COUNT(DISTINCT r.cd_prestador), SUM(r.vl_bruto), SUM(r.vl_glosa),
              SUM(r.vl_imposto), SUM(r.vl_liquido) FROM repasse r JOIN prestador p USING(cd_prestador)
              JOIN especialidade e USING(cd_especialidade) WHERE substr(r.dt_competencia,1,7)=? GROUP BY 1 ORDER BY 6 DESC""")
    d = [[Paragraph(x, sh) for x in ["Especialidade", "Médicos", "Bruto", "Glosa", "Impostos", "Líquido"]]]
    d += [[r[0], str(r[1])] + [brl(v) for v in r[2:]] for r in es]
    d.append(["TOTAL", str(sum(r[1] for r in es))] + [brl(sum(r[i] for r in es)) for i in range(2, 6)])
    t = Table(d, colWidths=[70 * mm, 22 * mm, 40 * mm, 32 * mm, 32 * mm, 40 * mm], repeatRows=1)
    t.setStyle(estilo_tabela([("ALIGN", (1, 0), (-1, -1), "RIGHT"), ("FONTSIZE", (0, 1), (-1, -1), 7.5),
                              ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("BACKGROUND", (0, -1), (-1, -1), CINZA)]))
    return el + [t]


def demonstrativo(con, rep):
    (cd_rep, cd_p, comp, dt_rep, bruto, glosa, imp, liq, fech, nm, crm, esp, vinc) = rep
    el = [Paragraph("DEMONSTRATIVO DE REPASSE MÉDICO", stit), Spacer(1, 3)]
    cab = [[Paragraph(f"<b>Prestador:</b> {cd_p} - {nm.upper()}", sp), Paragraph(f"<b>CRM:</b> {crm}", sp),
            Paragraph(f"<b>Especialidade:</b> {esp}", sp), Paragraph(f"<b>Vínculo:</b> {vinc}", sp)],
           [Paragraph(f"<b>Nº Repasse:</b> {cd_rep}", sp), Paragraph(f"<b>Competência:</b> {comp[5:7]}/{comp[:4]}", sp),
            Paragraph(f"<b>Dt. Repasse:</b> {dtbr(dt_rep)}", sp),
            Paragraph(f"<b>Situação:</b> {'FECHADO' if fech == 'S' else 'EM ABERTO'}", sp)]]
    t = Table(cab, colWidths=[90 * mm, 55 * mm, 70 * mm, 62 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), CINZA), ("BOX", (0, 0), (-1, -1), .5, AZUL),
                           ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    el += [t, Spacer(1, 5)]
    itens = con.execute("""SELECT i.cd_atendimento,i.dt_lancamento,i.cd_pro_fat,i.ds_procedimento,v.nm_convenio,i.tp_atendimento,
        i.vl_total_conta,i.pc_repasse,i.vl_repasse,i.vl_glosa,i.cd_centro_custo,c.ds_centro_custo
        FROM it_repasse i JOIN convenio v USING(cd_convenio) JOIN centro_custo c USING(cd_centro_custo)
        WHERE i.cd_repasse=? ORDER BY i.dt_lancamento, i.cd_atendimento""", (cd_rep,)).fetchall()
    hd = ["Atend.", "Paciente", "Dt. Lanç.", "Cód. Proc.", "Procedimento", "Convênio", "Tp. Atend.", "Vl. Conta",
          "% Rep.", "Vl. Repasse", "Glosa", "C. Custo"]
    d = [[Paragraph(x, sh) for x in hd]]
    for a in itens:
        d.append([str(a[0]), Paragraph(paciente(a[0]), sp), dtbr(a[1]), a[2], Paragraph(a[3], sp), a[4], a[5],
                  brl(a[6]), f"{a[7]:.0f}", brl(a[8]), brl(a[9]) if a[9] else "", Paragraph(f"{a[10]} - {a[11]}", sp)])
    cw = [16, 38, 16, 17, 46, 22, 17, 21, 9, 21, 16, 38]
    t = Table(d, colWidths=[x * mm for x in cw], repeatRows=1)
    t.setStyle(estilo_tabela([("FONTSIZE", (0, 1), (-1, -1), 6.6), ("ALIGN", (7, 1), (10, -1), "RIGHT")]))
    el += [t, Spacer(1, 8)]
    # apropriação por centro de custo + totais lado a lado
    ap = {}
    for a in itens:
        k = (a[10], a[11]); x = ap.setdefault(k, [0, 0.0, 0.0]); x[0] += 1; x[1] += a[8]; x[2] += a[9]
    da = [[Paragraph(x, sh) for x in ["C. Custo", "Qtd.", "Repasse", "Glosa", "Apropriado"]]]
    for (cd, ds), (n, v, g) in sorted(ap.items()):
        da.append([Paragraph(f"{cd} - {ds}", sp), str(n), brl(v), brl(g), brl(v - g)])
    ta = Table(da, colWidths=[52 * mm, 12 * mm, 26 * mm, 22 * mm, 26 * mm])
    ta.setStyle(estilo_tabela([("ALIGN", (1, 0), (-1, -1), "RIGHT"), ("FONTSIZE", (0, 1), (-1, -1), 6.8)]))
    dt = [["Repasse bruto", brl(bruto)], ["(-) Glosas", brl(glosa)], ["(-) Impostos retidos (11,75%)", brl(imp)],
          ["REPASSE LÍQUIDO", brl(liq)]]
    tt = Table(dt, colWidths=[55 * mm, 32 * mm])
    tt.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 8), ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                            ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("BACKGROUND", (0, -1), (-1, -1), CINZA),
                            ("BOX", (0, 0), (-1, -1), .5, AZUL), ("LINEABOVE", (0, -1), (-1, -1), .8, AZUL)]))
    blk = Table([[ta, "", tt]], colWidths=[142 * mm, 40 * mm, 92 * mm])
    blk.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    el.append(KeepTogether([Paragraph("APROPRIAÇÃO POR CENTRO DE CUSTO  /  TOTAIS DO REPASSE", spb), Spacer(1, 3), blk]))
    return el


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else "2026-09"
    con = sqlite3.connect(DB)
    comps = [r[0] for r in con.execute("SELECT DISTINCT substr(dt_competencia,1,7) FROM repasse ORDER BY 1")] if arg == "todas" else [arg]
    pasta = os.path.join(ROOT, "data", "pdf"); os.makedirs(pasta, exist_ok=True)
    nome = "demonstrativo_repasse_medico_mvsoul.pdf" if arg == "todas" else f"demonstrativo_repasse_medico_mvsoul_{arg}.pdf"
    out = os.path.join(pasta, nome)
    story = []
    for comp in comps:
        story += resumo(con, comp)
        reps = con.execute("""SELECT r.cd_repasse,r.cd_prestador,r.dt_competencia,r.dt_repasse,r.vl_bruto,r.vl_glosa,r.vl_imposto,
            r.vl_liquido,r.sn_fechado,p.nm_prestador,p.nr_crm,e.ds_especialidade,p.tp_vinculo FROM repasse r
            JOIN prestador p USING(cd_prestador) JOIN especialidade e USING(cd_especialidade)
            WHERE substr(r.dt_competencia,1,7)=? ORDER BY p.nm_prestador""", (comp,)).fetchall()
        for rep in reps:
            story += [PageBreak()] + demonstrativo(con, rep)
        story.append(PageBreak())
    story.pop()
    titulo = "Demonstrativo de Repasse Médico — Custos"
    comp_txt = f"{arg[5:7]}/{arg[:4]}" if arg != "todas" else "todas as competências"
    doc = SimpleDocTemplate(out, pagesize=landscape(A4), leftMargin=10 * mm, rightMargin=10 * mm, topMargin=27 * mm,
                            bottomMargin=12 * mm, title=titulo)
    f = cab_pagina(titulo, comp_txt)
    doc.build(story, onFirstPage=f, onLaterPages=f)
    print("OK ->", out)

if __name__ == "__main__":
    main()
