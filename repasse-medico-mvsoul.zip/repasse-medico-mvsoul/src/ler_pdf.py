#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lê PDFs do 'Demonstrativo de Repasse Médico' (padrão MV Soul / Custos), extrai os lançamentos
e gera: data/dados_repasse.json, data/dados_repasse.csv e os dashboards docs/index.html (desktop) e docs/mobile.html.
Uso:  python src/ler_pdf.py [arquivo.pdf ...]   (sem argumentos: lê data/pdf/*_AAAA-MM.pdf)
Requer: pdfplumber (pip install -r requirements.txt).
"""
import sys, re, json, csv, base64, os, glob
from datetime import datetime
import pdfplumber

CAMPOS = ["rep", "cd_med", "med", "crm", "esp", "vinc", "comp", "atend", "pac", "dt", "cod", "proc", "conv", "tp",
          "vl_conta", "pc", "vl_rep", "glosa", "cc", "cc_ds"]


def num(s):
    s = (s or "").strip()
    return float(s.replace(".", "").replace(",", ".")) if s else 0.0


def limpa(s):
    return re.sub(r"\s+", " ", (s or "").replace("\n", " ")).strip()


def cabecalho(txt):
    g = lambda p: (re.search(p, txt) or [None, ""])[1].strip()
    comp = re.search(r"Competência:\s*(\d{2})/(\d{4})", txt)
    return {"cd_med": int(g(r"Prestador:\s*(\d+)") or 0), "med": g(r"Prestador:\s*\d+\s*-\s*(.+?)\s+CRM:"),
            "crm": g(r"CRM:\s*(CRM-[A-Z]{2}\s*\d+)"), "esp": g(r"Especialidade:\s*(.+?)\s+Vínculo:"),
            "vinc": g(r"Vínculo:\s*([^\n]+)"), "rep": int(g(r"Nº Repasse:\s*(\d+)") or 0),
            "comp": f"{comp[2]}-{comp[1]}" if comp else ""}


def ler_pdf(caminho):
    itens, ctx = [], None
    with pdfplumber.open(caminho) as pdf:
        for pg in pdf.pages:
            txt = pg.extract_text() or ""
            if "DEMONSTRATIVO DE REPASSE MÉDICO" in txt:
                ctx = cabecalho(txt)
            if not ctx:
                continue
            for tb in pg.extract_tables():
                if not tb or not tb[0] or not limpa(tb[0][0]).startswith("Atend"):
                    continue
                for r in tb[1:]:
                    if len(r) < 12 or not limpa(r[0]).isdigit():
                        continue
                    d = limpa(r[2]); cc = limpa(r[11]).split(" - ", 1)
                    itens.append({**ctx, "atend": int(limpa(r[0])), "pac": limpa(r[1]),
                                  "dt": f"{d[6:10]}-{d[3:5]}-{d[0:2]}", "cod": limpa(r[3]), "proc": limpa(r[4]),
                                  "conv": limpa(r[5]), "tp": limpa(r[6]), "vl_conta": num(r[7]), "pc": num(r[8]),
                                  "vl_rep": num(r[9]), "glosa": num(r[10]), "cc": int(cc[0]),
                                  "cc_ds": cc[1] if len(cc) > 1 else ""})
    return itens


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TPL = os.path.join(ROOT, "src", "templates")
SAIDAS = [("dashboard_desktop.html", "index.html"), ("dashboard_mobile.html", "mobile.html")]  # -> docs/


def main(pdfs):
    todos, embutidos = [], []
    for p in pdfs:
        it = ler_pdf(p)
        print(f"{os.path.basename(p)}: {len(it)} lançamentos")
        todos += it
        with open(p, "rb") as fb:  # PDF de exemplo embutido no HTML (lido no navegador ao abrir)
            embutidos.append({"nome": os.path.basename(p), "esperado": len(it),
                              "b64": base64.b64encode(fb.read()).decode()})
    dados = {"gerado_em": datetime.now().strftime("%d/%m/%Y %H:%M"),
             "origem": "PDF: " + ", ".join(os.path.basename(p) for p in pdfs), "itens": todos}
    with open(os.path.join(ROOT, "data", "dados_repasse.json"), "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False)
    with open(os.path.join(ROOT, "data", "dados_repasse.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS, delimiter=";")
        w.writeheader(); w.writerows(todos)
    js, pj = json.dumps(dados, ensure_ascii=False), json.dumps(embutidos)
    os.makedirs(os.path.join(ROOT, "docs"), exist_ok=True)
    for modelo, saida in SAIDAS:
        html = open(os.path.join(TPL, modelo), encoding="utf-8").read()
        with open(os.path.join(ROOT, "docs", saida), "w", encoding="utf-8") as f:
            f.write(html.replace('"__DADOS__"', js).replace('"__PDFS__"', pj))
        print("gerado: docs/" + saida)
    print("OK -> data/dados_repasse.json, data/dados_repasse.csv")


if __name__ == "__main__":
    pdfs = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, "data", "pdf", "demonstrativo_repasse_medico_mvsoul_20??-??.pdf")))
    if not pdfs:
        sys.exit("Nenhum PDF encontrado. Rode antes src/gerar_pdf.py ou passe os PDFs como argumento.")
    main(pdfs)
