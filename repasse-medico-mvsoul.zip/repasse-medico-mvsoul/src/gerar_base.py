#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gera a base fictícia de repasse médico (SQLite) no layout inspirado no MV Soul.
Tabelas: especialidade, centro_custo, convenio, prestador, regra_repasse, repasse, it_repasse.
Saída: data/repasse_medico_mvsoul.db   (semente fixa -> sempre os mesmos dados)
"""
import sqlite3, random, os
from datetime import date

random.seed(42)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, "data", "repasse_medico_mvsoul.db")
ANO, MESES = 2026, range(1, 11)
CORES = ["#2f7ed8", "#1aa97b", "#e8a317", "#d9534f", "#8e6bd1", "#17a2b8", "#e06fa6", "#7a8b99"]

ESPECIALIDADES = {1: "Cardiologia", 2: "Ortopedia", 3: "Ginecologia/Obstetrícia", 4: "Cirurgia Geral",
                  5: "Pediatria", 6: "Neurologia", 7: "Oncologia", 8: "Anestesiologia", 9: "Radiologia", 10: "Urologia"}
PROCS = {  # esp: [(cod_pro_fat, descrição, valor base)]
    1: [("20101010", "Consulta cardiológica", 320), ("40101037", "Ecocardiograma", 480), ("40304361", "Cateterismo cardíaco", 6200)],
    2: [("20101012", "Consulta ortopédica", 300), ("30725119", "Artroplastia de joelho", 18500), ("30715016", "Artroscopia", 7400)],
    3: [("20101013", "Consulta ginecológica", 280), ("31309053", "Parto cesariana", 5200), ("31303102", "Histerectomia", 8900)],
    4: [("30602270", "Colecistectomia videolaparoscópica", 7800), ("30701016", "Herniorrafia", 4300), ("30602017", "Apendicectomia", 5100)],
    5: [("20101014", "Consulta pediátrica", 250), ("10102019", "Visita hospitalar pediatria", 190), ("30913010", "Fototerapia", 420)],
    6: [("20101015", "Consulta neurológica", 340), ("40105012", "Eletroencefalograma", 390), ("30303037", "Craniotomia", 24500)],
    7: [("20101016", "Consulta oncológica", 380), ("28011018", "Quimioterapia ambulatorial", 4800), ("30603016", "Ressecção tumoral", 15200)],
    8: [("30801011", "Anestesia geral", 2100), ("30801020", "Raquianestesia", 1500), ("30801038", "Sedação", 780)],
    9: [("40808041", "Tomografia de abdome", 690), ("40813096", "Ressonância de crânio", 1150), ("40803029", "Ultrassom abdominal", 210)],
    10: [("20101017", "Consulta urológica", 290), ("31104030", "Prostatectomia", 12800), ("31101107", "Litotripsia", 5600)],
}
CENTROS = {101: "Centro Cirúrgico", 102: "UTI Adulto", 103: "Pronto Atendimento", 104: "Ambulatório",
           105: "Hemodinâmica", 106: "Diagnóstico por Imagem", 107: "Internação Apartamento", 108: "Maternidade"}
CC_POR_ESP = {1: [105, 104, 102], 2: [101, 104], 3: [108, 101, 104], 4: [101, 107], 5: [103, 104, 107],
              6: [104, 102, 101], 7: [104, 107, 101], 8: [101, 108], 9: [106], 10: [104, 101]}
CONVENIOS = {1: ("Unimed", .45), 2: ("Bradesco Saúde", .15), 3: ("SulAmérica", .12),
             4: ("Amil", .13), 5: ("SUS", .08), 6: ("Particular", .07)}
PC_BASE = {1: 62, 2: 60, 3: 58, 4: 60, 5: 45, 6: 75}  # % de repasse por convênio (regra)
NOMES = ["Ricardo", "Fernanda", "Carlos", "Mariana", "João", "Patrícia", "André", "Luciana", "Paulo", "Camila",
         "Eduardo", "Renata", "Marcelo", "Juliana", "Roberto", "Tatiana", "Fábio", "Aline", "Sérgio", "Beatriz"]
SOBRE = ["Almeida", "Barbosa", "Cardoso", "Dias", "Esteves", "Ferraz", "Gomes", "Henrique", "Ibrahim", "Junqueira",
         "Lopes", "Moreira", "Nogueira", "Oliveira", "Pereira", "Queiroz", "Ribeiro", "Souza", "Teixeira", "Vasconcelos"]


def gerar_banco():
    if os.path.exists(DB):
        os.remove(DB)
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE especialidade(cd_especialidade INTEGER PRIMARY KEY, ds_especialidade TEXT);
    CREATE TABLE centro_custo(cd_centro_custo INTEGER PRIMARY KEY, ds_centro_custo TEXT);
    CREATE TABLE convenio(cd_convenio INTEGER PRIMARY KEY, nm_convenio TEXT);
    CREATE TABLE prestador(cd_prestador INTEGER PRIMARY KEY, nm_prestador TEXT, nr_crm TEXT,
        cd_especialidade INTEGER, tp_vinculo TEXT, sn_ativo TEXT DEFAULT 'S');
    CREATE TABLE regra_repasse(cd_regra INTEGER PRIMARY KEY, cd_convenio INTEGER, pc_repasse REAL, ds_regra TEXT);
    CREATE TABLE repasse(cd_repasse INTEGER PRIMARY KEY, cd_prestador INTEGER, dt_competencia TEXT, dt_repasse TEXT,
        vl_bruto REAL, vl_glosa REAL, vl_imposto REAL, vl_liquido REAL, sn_fechado TEXT);
    CREATE TABLE it_repasse(cd_it_repasse INTEGER PRIMARY KEY, cd_repasse INTEGER, cd_atendimento INTEGER,
        cd_pro_fat TEXT, ds_procedimento TEXT, cd_convenio INTEGER, tp_atendimento TEXT, dt_lancamento TEXT,
        vl_total_conta REAL, cd_regra INTEGER, pc_repasse REAL, vl_repasse REAL, vl_glosa REAL,
        cd_centro_custo INTEGER);
    """)
    c.executemany("INSERT INTO especialidade VALUES(?,?)", ESPECIALIDADES.items())
    c.executemany("INSERT INTO centro_custo VALUES(?,?)", CENTROS.items())
    c.executemany("INSERT INTO convenio VALUES(?,?)", [(k, v[0]) for k, v in CONVENIOS.items()])
    c.executemany("INSERT INTO regra_repasse VALUES(?,?,?,?)",
                  [(k, k, PC_BASE[k], f"Repasse padrão {CONVENIOS[k][0]}") for k in CONVENIOS])
    # prestadores (40)
    medicos, nomes_usados = [], set()
    for i in range(40):
        while True:
            n = f"Dr(a). {random.choice(NOMES)} {random.choice(SOBRE)}"
            if n not in nomes_usados:
                nomes_usados.add(n); break
        esp = (i % 10) + 1
        medicos.append((1000 + i, n, f"CRM-SP {random.randint(60000, 199999)}", esp,
                        random.choice(["Corpo Clínico", "Corpo Clínico", "PJ", "Plantonista"]),
                        random.choice([.6, .8, 1, 1.2, 1.6, 2.2])))
    c.executemany("INSERT INTO prestador(cd_prestador,nm_prestador,nr_crm,cd_especialidade,tp_vinculo) VALUES(?,?,?,?,?)",
                  [m[:5] for m in medicos])
    conv_ids, conv_pesos = list(CONVENIOS), [v[1] for v in CONVENIOS.values()]
    cd_rep = cd_it = 0
    atend = 500000
    for cd_prest, _, _, esp, _, volume in medicos:
        for mes in MESES:
            cd_rep += 1
            comp = date(ANO, mes, 1)
            dt_rep = date(ANO, mes + 1, 10) if mes < 12 else date(ANO + 1, 1, 10)
            itens, bruto, glosa = [], 0.0, 0.0
            for _ in range(max(3, int(random.gauss(14, 4) * volume))):
                cd_it += 1; atend += random.randint(1, 9)
                cod, desc, base = random.choice(PROCS[esp])
                conv = random.choices(conv_ids, conv_pesos)[0]
                total = round(base * random.uniform(.85, 1.2), 2)
                pc = PC_BASE[conv]
                rep = round(total * pc / 100, 2)
                gl = round(rep * random.uniform(.1, .6), 2) if random.random() < .07 else 0.0
                tp = "Ambulatorial" if cod.startswith("20") or cod.startswith("4") else random.choice(["Internação", "Urgência"])
                cc = random.choice(CC_POR_ESP[esp])
                dia = date(ANO, mes, random.randint(1, 28))
                itens.append((cd_it, cd_rep, atend, cod, desc, conv, tp, dia.isoformat(), total, conv, pc, rep, gl, cc))
                bruto += rep; glosa += gl
            imposto = round((bruto - glosa) * .1175, 2)  # ISS+PIS/COFINS fictícios
            c.execute("INSERT INTO repasse VALUES(?,?,?,?,?,?,?,?,?)",
                      (cd_rep, cd_prest, comp.isoformat(), dt_rep.isoformat(), round(bruto, 2), round(glosa, 2),
                       imposto, round(bruto - glosa - imposto, 2), "S" if mes < 10 else "N"))
            c.executemany("INSERT INTO it_repasse VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", itens)
    c.commit()
    return c


if __name__ == "__main__":
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    gerar_banco()
    print("OK ->", DB)
