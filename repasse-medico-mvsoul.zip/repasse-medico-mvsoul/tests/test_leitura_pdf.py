"""Confere se a leitura do PDF devolve exatamente os lançamentos do banco (quantidade e valor)."""
import sqlite3, sys, unittest, pathlib
R = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(R / "src"))
import ler_pdf  # noqa: E402

class LeituraPDF(unittest.TestCase):
    def test_pdf_igual_ao_banco(self):
        con = sqlite3.connect(R / "data" / "repasse_medico_mvsoul.db")
        pdfs = sorted((R / "data" / "pdf").glob("*_20??-??.pdf"))
        self.assertTrue(pdfs, "gere os PDFs antes (python run_all.py)")
        for pdf in pdfs:
            comp = pdf.stem[-7:]
            itens = ler_pdf.ler_pdf(str(pdf))
            n, v = con.execute("""SELECT COUNT(*), SUM(vl_repasse) FROM it_repasse i JOIN repasse r USING(cd_repasse)
                                  WHERE substr(r.dt_competencia,1,7)=?""", (comp,)).fetchone()
            self.assertEqual(len(itens), n, comp)
            self.assertAlmostEqual(sum(i["vl_rep"] for i in itens), v, places=1, msg=comp)

if __name__ == "__main__":
    unittest.main()
